const form = document.getElementById("form");

function calculate(params) {
    params.preventDefault();

    let massAlice = document.getElementById('mass_id_one').value; 
    let heightAlice = document.getElementById('height_id_one').value; 
    let massBob = document.getElementById('mass_id_two').value; 
    let heightBob = document.getElementById('height_id_two').value;
    
    let BMIAlice = massAlice/(heightAlice*heightAlice);
    let BMIBob = massBob/(heightBob*heightBob);

    const resultDiv = document.getElementById('result-section');

    let compare;

    if(BMIAlice == BMIBob){
       compare = "Their BMI is Equal." ;
    }else if(BMIAlice > BMIBob){
        compare = "BMI of Alice is bigger then Bob";
    }else{
        compare = "BMI of Bob is bigger then Alice";  
    }

    let result = "<h3>BMI of Alice is "+ BMIAlice + "</h3><br>" + "<h3>BMI of Bob is "+ BMIBob + "</h3><br>" +"<h3>And "+ compare +"</h3>";

    resultDiv.innerHTML= result;
}

form.addEventListener('submit', calculate);
